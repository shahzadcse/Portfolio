
$(document).ready(function() { 
// for the validation of contact form
	if($("#contact-form").length > 0){

		$(".ph-number").mask("999-999-9999",{placeholder:" "});
		
		$("#contact-form").validate({
			rules: {
				fName: {
					required: true,
					maxlength: 50
				},
				lName: {
					required: true,
					maxlength: 50
				},
				eMail: {
				  required: true,
				  email: true
				},
				messageArea: {
				  required: true,
				  maxlength: 100
				},
				PNumber:{
					required:true
				},
				zip:{
					required:true,
					number: true
				},
				event:{
					maxlength: 50
				}
			},
			messages: contact.errorMessage 
		});
		
		//init, set watermark text and class
		$('.event').val(watermark).addClass('watermark');
 
		//if blur and no value inside, set watermark text and class again.
		$('.event').blur(function(){
			if ($(this).val().length == 0){
				$(this).val(watermark).addClass('watermark');
			}
		});
 
		//if focus and text is watermrk, set it to empty and remove the watermark class
		$('.event').focus(function(){
			if ($(this).val() == watermark){
				$(this).val('').removeClass('watermark');
			}
		});
	}
	
	
	if($("#searchevent").length > 0){
		//init, set watermark text and class
		$('#searchevent').val("EVENT SEARCH").addClass('watermark');
 
		//if blur and no value inside, set watermark text and class again.
		$('#searchevent').blur(function(){
			if ($(this).val().length == 0){
				$(this).val("EVENT SEARCH").addClass('watermark');
			}
		});
 
		//if focus and text is watermrk, set it to empty and remove the watermark class
		$('#searchevent').focus(function(){
			if ($(this).val() == watermark){
				$(this).val('').removeClass('watermark');
			}
		});
	}
	if($('.inner-wrapper .events.events-fixedsize li').length > 0){
		$('.inner-wrapper .events.events-fixedsize > li:nth-child(odd)').addClass('odd')
	}

 
		  // Hero carousel center allignment end
		
		 $(".select-filter").selectbox().bind(); 
		
  		 //table right border
  		 $(".event-result-container .sort-table td:last-child").css({'border-right':'none','padding-left':'6px','width':'116px'});
 //	hero carousel
				$('#hero-carousel').carouFredSel({
					auto: true,					 
				   	pagination :{
					   container : '.pager'
					   },			 
					scroll : {
						items : 1,
						duration : 1000 
						} 
				});
	 
	 //featured event carousel
	   
				$('.event-list').carouFredSel({
					auto: true,
					pagination :{
					   container : '.pager-event'
					  },						 
					scroll : {
						items : 4,
						duration : 500 
						} 
				});
		
	 
	 
	  //	fma carousel
				$('#overview').carouFredSel({
					auto: true,
					prev: '#prev',
					next: '#next',					 
					scroll : {
						items : 4,
						duration : 500 
						} 
				});
		
		
		//carousel sizing 
		
	carsize();
	
	 
		 
		
		$(window).bind("resize", function(){ 
		carsize();
		 
		 });
   	
});  
		

function carsize(){
	var docWidth = $(window).width();
	 var $imgMargin = docWidth-1403;
		 $('#hero-carousel a').css('backgroundPosition', ($imgMargin/2)+"px");
	
	if(docWidth > 1024 )
	{
	var marginVal = (docWidth - 950)/2;
	$('#slider1 .pager').css({marginLeft: marginVal+'px'}); 
	$('#hero-carousel a span').css({marginLeft: docWidth - (marginVal+$('#hero-carousel a span').width())+'px'});
	
	}
	else{
		$('#slider1 .pager').css({marginLeft: 23}); 
	    $('#hero-carousel a span').css({marginLeft: docWidth - $('#hero-carousel a span').width()*2+'px' });
		
	 	 
		} 
}