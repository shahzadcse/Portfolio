$(document).ready( function(){	
		/*Highlight the respective navigation tabs on thier respective pages*/
		if($('#prepcenter').length >0)
		{
			$('#prepcenter .preplianc').addClass('selectednavtab');			
		}
		if($('#aboutgedtest').length >0)
		{
			$('#aboutgedtest .aboutlianc').addClass('selectednavtab');	
			$('#aboutgedtest .topnavfirstli').addClass('selectednavlftcurve');			
		}
		if($('#contactus').length >0)
		{
			$('#contactus .contactlianc').addClass('selectednavtab');			
		}		
		
		
		/*left curve of first tab in top navigation in hover state*/
		$('.topnavfirstli .aboutlianc').hover(
				function(){
					$('.topnavul .topnavfirstli').addClass('topnavfirstliHover')	
				},
				function(){
					$('.topnavul .topnavfirstli').removeClass('topnavfirstliHover')	
				}
		)
		
		/*FAQ section on Prep Center - books and more page STARTS*/
		$('.faqcontent ul li:first div').css('display','block')
		$('.faqcontent ul li a').click( function(){
			$('.faqcontent ul li div').hide();
			$('.faqcontent ul li').removeClass('selected');
			$(this).next().show();
			$(this).parents('li').addClass('selected')
			return false;
			}
		)
		/*FAQ section on Prep Center - books and more page ENDS*/
		
		
		/*Accordion starts*/
		$('.accordion .barbox:first .accordata').show();
		$('.accordion .barbox:first .clickaccor').addClass('activeaccorbar').removeAttr('href')
		$('.accordion .barbox .clickaccor').click( function(e){
			//$(this).e.preventDefault();
			if($(this).hasClass('activeaccorbar'))
			{
				$(this).click(function(e){$(this).e.preventDefault();})
			}
			else{
				$('.accordion .accordata').slideUp(500);
				$('.accordion .barbox .clickaccor').removeClass('activeaccorbar').attr('href','#')
				$(this).addClass('activeaccorbar').parents('.barbox').children('.accordata').slideDown(500);
				$(this).removeAttr('href')
				return false;	
				}
			}
			
		)
		/*Accordion ends*/
		
		
		/*Home page discount popup starts*/		
		var halfdocwidth = ($(document).width())/2
		var halfdscntpopupwidth = ($('.discountpopup').width())/2
		var mrgnleftforpopup = halfdocwidth - halfdscntpopupwidth;
		$('.discountpopup').css('margin-left',mrgnleftforpopup)		
		/*Home page discount popup ends*/
		
		/*--- Muralidhar new addons ---- */

		/*FAQ section on Casio Calculator page STARTS By Murali 20092011*/
		/*$('.faqcontent1 ul li:first div').css('display','block')
		$('.faqcontent1 ul li a').click( function(){
			$('.faqcontent1 ul li div').hide();
			$('.faqcontent1 ul li').removeClass('selected');
			$(this).next().show();
			$(this).parents('li').addClass('selected')
			return false;
			}
		)*/
		
		/*FAQ section on Casio Calculator page ENDS*/
		
		
		/*Prep Center Landing page - starts*/		
			//Language change click events
		$('.langdiv .spanlang').click ( function(){
			$(this).removeAttr('href').css('color','#0093C6')
			$('.langdiv .englang').attr('href','#').css('color','#111111')
			//$('.booksforprac img').attr('src','../images/booksforpracspan.png')
			$('.langchange-engimg').hide();
			$('.langchange-spanimg').show();
			$('.langchange-engisbn').html('978-1-419-05334-4')
			$('.langchange-engprice').html('$24.30')
			$('.prepcenter .pdflist').hide()
			$('.prepcenter .pdflist-span').show()
			$('.bynwenglang').hide();
			$('.bynwspanlang').css('display','block');	
			$('.buktitlelangchange').html('Preparacion completa para el GED<sup>&#0174;</sup>')
			return false;			
			}
		)
		$('.langdiv .englang').click ( function(){
			$(this).removeAttr('href').css('color','#0093C6')
			$('.langdiv .spanlang').attr('href','#').css('color','#111111')
			//$('.booksforprac img').attr('src','../images/booksforprac.png')
			$('.langchange-engimg').show();
			$('.langchange-spanimg').hide();
			$('.langchange-engisbn').html('978-1-419-05399-3')	
			$('.langchange-engprice').html('$18.25')
			$('.prepcenter .pdflist').show()
			$('.prepcenter .pdflist-span').hide()	
			$('.bynwenglang').show();
			$('.bynwspanlang').hide();	
			$('.buktitlelangchange').html('Complete GED<sup>&#0174;</sup> Preparation, 2nd edition')		
			return false;			
			}
		)	
		
			// Call to Carousel
		if($('#charCarousel').length > 0) 
		{
			$('#charCarousel').jcarousel({
			//wrap: 'circular',
			//start: 1
			});		
		}
			//Carousel  - Show book details 
		var waitime;
		var relofanc;		
		//code update by Kiran //		
		var divToDisplay = "";
			var divhover = "";
			var displayKey = "";
		$('#charCarousel li a').live( 'mouseover',  function(e){
			clearTimeout(waitime);
			var title = $(this).attr('title');
			var language = "";		
			
			
			if(title.indexOf('Math') >0)
			{
				language = "Math";
				divToDisplay = "mathdiv";
				divhover = "mathdivhover";
				displayKey = "mathkey";
				//alert("Language :" + language + ", DivToDisplay :" + divToDisplay + ", Divhover" + divhover);
				//$('.mathkey').hide();
				//$(this).hide();
				$('.bksovlay').hide();
				
			}
			else if(title.indexOf('Writing') >0)
			{
				language = "Writing";
				divToDisplay = "writingdiv";
				divhover = "writingdivhover";
				displayKey = "writingkey";
				$('.bksovlay').hide();
				//alert("Language :" + language + ", DivToDisplay :" + divToDisplay + ", Divhover :" + divhover);
			}
			else if(title.indexOf('Reading') >0)
			{
				language = "Reading";
				divToDisplay = "readingdiv";
				divhover = "readingdivhover";
				displayKey = "readingkey";
				$('.bksovlay').hide();
				//alert("Language :" + language + ", DivToDisplay :" + divToDisplay + ", Divhover :" + divhover);
			}
			else if(title.indexOf('Science') >0)
			{
				language = "Science";
				divToDisplay = "sciencediv";
				divhover = "sciencedivhover";
				displayKey = "sciencekey";
				$('.bksovlay').hide();
				//alert("Language :" + language + ", DivToDisplay :" + divToDisplay + ", Divhover :" + divhover);
			}
			else if(title.indexOf('Social Studies') >0)
			{
				language = "Social Studies";
				divToDisplay = "socialstudiesdiv";
				divhover = "socialstudiesdivhover";
				displayKey = "socialstudieskey";
				$('.bksovlay').hide();
				//alert("Language :" + language + ", DivToDisplay :" + divToDisplay + ", Divhover :" + divhover);
			}
					
			
			
			$('#charCarousel li a').find(divToDisplay).removeClass(divhover);
			//jQuery(".hoverdivs .bksovlay:eq:not(" +  $(this).attr('rel') + ")").hide()
			var topdist = $(this).offset().top - 40 + 'px';
			var leftdist = $(this).offset().left + $(this).width() - 10 + 'px';
			/*if(navigator.userAgent.indexOf('Apple') > 0)
			{
				topdist = parseInt(topdist) + 40 + 'px';	
			}*/	
			relofanc = $(this).attr('rel');						
			$('.hoverdivs .bksovlay' + "#" + displayKey).css({'top':topdist,'left':leftdist}).show();
			var tagLineObj = $(divToDisplay, this);
			if(!tagLineObj.hasClass(divhover)) {
				$(divToDisplay, this).addClass(divhover);
			}
			
		});
		
			$('#charCarousel li a').live( 'mouseout',  function(){
			var that = this;
			waitime = setTimeout( function(){
							 $(divToDisplay, that).removeClass(divhover);
				 
				$('.bksovlay').hide();
			}, 300);
		});		
		//Code ends here by kiran
		$('.bksovlay').hover( function() {
		
		    //var that=$('.bksovlay');
			//alert(that);			
			clearTimeout(waitime);			
			},
			function(){
				var that = $('.bksovlay');
				waitime = setTimeout( function(){
					if(that.is(':visible'))
					{
						
							that.hide();
							$('#charCarousel li a').find(divToDisplay).removeClass(divhover);
					}				
				},300);
		});
		
		$('#charCarousel li a').click ( function(){
		var title = $(this).attr('title');
		if(title.indexOf("Math")>0)
		{
		$('#imgsforsbjcts img').hide();
	    $('#imgsforsbjcts img:eq('+ 2 +')').show();
		}
		else if(title.indexOf('Science') >0)
			{
				$('#imgsforsbjcts img').hide();
				$('#imgsforsbjcts img:eq('+ 3 +')').show();
			}
		});
		/*Prep Center Landing page - Langauge change ends*/	
		
		
		/*FAQ and Home page - Path to GED Credential popup starts*/	
		var halfdocwidth = ($(document).width())/2
		var halfdscntpopupwidth = ($('.gedpathbox').width())/2
		var halfmobappwidth = ($('.mobappolay').width())/2
		var mrgnleftforgedpath = halfdocwidth - halfdscntpopupwidth;	
		var mrgnleftformobapp = halfdocwidth - halfmobappwidth;	
		$('.gedpathbox').css('left',mrgnleftforgedpath)
		$('.mobappolay').css('left',mrgnleftformobapp)
					
		$('.showthebox, .gotogedpath, .mobilepageprevw').click ( function(){
			$(document.body).css('overflow-x','hidden');
			$('#blackfilm').css({'width':$(document).width(),'height':$(document).height(),'opacity':'.7'}).show()			
			$('.gedpathbox, .mobappolay').show();	
			return false;		
			}
		)	
		$('.gedpathbox .closebtn, .mobappolay .closebtn').click(function(){
			$(document.body).removeAttr('style');
			$('#blackfilm, .gedpathbox, .mobappolay , .prevPopupiphone').hide()			
			return false;		
			}
		)	
		
		$('.viewappanc').click ( function(){
		
			$(document.body).css('overflow-x','hidden');
			$('#blackfilm').css({'width':$(document).width(),'height':$(document).height(),'opacity':'.7'}).show()			
			$('.prevPopupiphone').show();	
			return false;		
			}
		)	
		
		$('.viewappanc2').click ( function(){
			$(document.body).css('overflow-x','hidden');
			$('#blackfilm').css({'width':$(document).width(),'height':$(document).height(),'opacity':'.7'}).show()			
			$('.prevPopupipad').show();	
			return false;		
			}
		)	
		$('.prevPopupipad .closebtn').click(function(){
			window.location.reload();
			$(document.body).removeAttr('style');
			$('#blackfilm, .prevPopupipad').hide()			
			return false;		
			}
		)
		$('.viewappanc3').click ( function(){
			$(document.body).css('overflow-x','hidden');
			$('#blackfilm').css({'width':$(document).width(),'height':$(document).height(),'opacity':'.7'}).show()			
			$('.prevPopupanroid').show();	
			//alert("hihi");
			return false;		
			}
		)	
		$('.prevPopupanroid .closebtn').click(function(){
			window.location.reload();
			$(document.body).removeAttr('style');
			$('#blackfilm, .prevPopupanroid').hide()			
			return false;		
			}
		)
		/*FAQ and Home page - Path to GED Credential popup ends*/
		
		
		/*Ronnies code*/
		/* Mobile App tab structure starts*/		
	
		/*$('.iphoneshow').click ( function(){
			$('div#iphonedetails').show()	
			$('div#ipaddetails').hide()
			$('div#androiddetails').hide()
			$('.mobarrow').css('left','0px')
			return false;		
			}
		)

		$('.ipadshow').click ( function(){
			$('div#iphonedetails').hide()	
			$('div#ipaddetails').show()
			$('div#androiddetails').hide()
			$('.mobarrow').css('left','188px')
			return false;		
			}
		)

		$('.andshow').click ( function(){
			$('div#iphonedetails').hide()	
			$('div#ipaddetails').hide()
			$('div#androiddetails').show()
			$('.mobarrow').css('left','374px')
			return false;		
			}
		)*/
		
		//$('.iphoneshow').parents('li').addClass('selected')
		$('.iphoneshow').addClass('selectedmobdev')
		
		/*$('.mobileselector ul li a').click( function (){
				$('.mobileselector ul li').removeClass('selected')
				$(this).parents('li').addClass('selected')
				$('.mobileselector ul li a').removeClass('selectedmobdev')
				$(this).addClass('selectedmobdev')
			}
		)*/
		
		/*Overlay for Online Practise test page starts*/
		
		$('.optoverlay .closeform').click ( function(){
			$(document.body).removeAttr('style');
			window.location.href = 'onlinepracticetest.html'
			return false;		
			}
		)		
		
		//Below code is for aligning the popup overlay in the certer
		
		var halfdocwidth = ($(document).width())/2
		var halfdscntpopupwidth = ($('.optoverlay').width())/2
		var mrgnleftforpopup = halfdocwidth - halfdscntpopupwidth;
		$('.optoverlay').css('margin-left',mrgnleftforpopup)
		
		/*Overlay for Online Practise test page ends*/
		
		
		/*Product Details tabs coding start*/	
		//$('#imgsforsbjcts img:eq(0)').show();	
		var indexoftab;
		$('.tabsectionholder ul li a').click( function(){
			indexoftab = $(this).parent().index();
			$('#imgsforsbjcts img').hide();
			$('#imgsforsbjcts img:eq('+ indexoftab +')').show();
			$('.tabsectionholder ul li a').removeClass('selected');
			$(this).addClass('selected');
			var tab = $(this).attr('id');
			$('.section').hide();
			$("#" + tab + "section").show();
			return false;						   
		});
		/*Product Details tabs coding ends*/



		/*FAQs page content change starts*/
		$('#faqpageuldata li a').click( function(){
			var indexofAnc = $(this).parent().index();
			$('#faqpageuldata li a').removeClass('whitetxt')
			$('#faqpageuldata li').removeClass('greenarrwforselection');
			$(this).parent().addClass('greenarrwforselection');
			$(this).addClass('whitetxt')
			$('#faqQnAouterbox div').hide();
			$('#faqQnAouterbox div:eq(' + indexofAnc + ')').show();
			return false;
			}
		)			
		/*FAQs page content change starts*/
		
							
	}
)