﻿$(document).ready( function(){	



		/*Iphone and Android slider on home page STARTS*/
		
		initiateSlider('.iphoneappsslider');
		//initiateSlider('.androidappsslider');
		//initiateSlider('.ipadappsslider');
		//$('prevPopupiphone').location.reload();
		
		function initiateSlider(sliderElement){
				
		
			var sliderCounter = jQuery("#slideCounter");
			sliderCounter.val("1");	
			
			
			var vsliderCounter = jQuery("#vslideCounter");
			vsliderCounter.val("1");
			
			
			var sliderContext = sliderElement;
			
			var countofmobileapps = $('ul#htop1 li', sliderContext).length;
			
			var countofvmobileapps = $('ul#htop1 li ul li', sliderContext).length;
			
			
			  //countofvmobileapps = $('ul#htop1 li ul#fc'+counterxV).children('li').length;
		 //alert("countofvmobileapps = "+countofvmobileapps);
			  
			  if(countofvmobileapps == 1){	
			 			
							$('.phonedownclick').removeClass('addcursoronimg phonedownclickenab').addClass('phonedownclickdis');
							 	}
					else{					
							$('.phonedownclick').addClass('addcursoronimg phonedownclickenab')
									 	}
	
				/*if(countofvmobileapps > 1){					
							$('.phonedownclick').addClass('addcursoronimg phonedownclickenab')
									 	}*/
			//alert("countofmobileapps = "+ countofmobileapps);
			countofmobileapps = countofmobileapps - countofvmobileapps;
			//alert("countofmobileapps = "+ countofmobileapps);
			
			var widthofappsul = $('ul#htop1 li a', sliderContext).width() * countofmobileapps;
			widthofappsul =  widthofappsul + 'px';
			$('ul#htop1', sliderContext).css('width',widthofappsul);
			$('.phonerightclick').addClass('addcursoronimg');
			
			var heightofappsul = $('ul#htop1 li ul li a', sliderContext).height() * countofvmobileapps;
			heightofappsul = heightofappsul + 'px';
			$('ul#htop1 li ul', sliderContext).css('height',heightofappsul);
			//$('.phoneupclick').addClass('addcursoronimg')	
			
			 var counterxV;
				 counterxV= vsliderCounter.val();
										 
			var leftpos;
			var rightpos;
			var counterxH;
			counterxH = sliderCounter.val();  
			
		$(".phonerightclick").each(function (i) {
        $("#htop1 ul li ul.vsliderimg").css("top","0px");
      });
	$(".phoneleftclick").each(function (i) {
        $("#htop1 ul li ul.vsliderimg").css("top","0px");
      });
			
		$('.prevPopupiphone .closebtn').click(function(){
			window.location.reload();
				counterxH = 1;
				counterxV = 1;
			$(document.body).removeAttr('style');
			$('#blackfilm, .prevPopupiphone').hide();
						
			return false;		
			}
		)
				
			$('.phonerightclick').click(function(){
				 
					 //countofvmobileapps = $('ul#htop1 li ul#fc'+counterxV).children('li').length;
					 
		       //alert("countofvmobileapps = "+countofvmobileapps);
					 vsliderCounter.val("1");
					var visibleSlider = 'ul#htop1:visible';
					//alert(visibleSlider);
					if($(visibleSlider).is(':animated')) {
						return false;
					}
					//alert(countofmobileapps);
					if(counterxH < countofmobileapps) {			
						counterxH = parseInt(counterxH) + 1;
						
						sliderCounter.val(counterxH);
						counterxV = counterxH;
						//alert("counterxV in Right=" + counterxV);
						countofvmobileapps = $('ul#htop1 li ul#fc'+counterxV+' li', sliderContext).length;
						
						
						 if(countofvmobileapps == 0){					
							$('.phonedownclick').removeClass('addcursoronimg phonedownclickenab').addClass('phonedownclickdis');
							 	}
					else{					
							$('.phonedownclick').removeClass('phonedownclickdis').addClass('addcursoronimg phonedownclickenab');
									 	}
						//alert(countofvmobileapps);
						
						if(counterxH == 1){
								$('.phoneleftclick').removeClass('addcursoronimg phoneleftclickenab').addClass('phoneleftclickdis');
							}
						//alert($(visibleSlider).css('left'));
						if(counterxH <= countofmobileapps){	
						var leftDist =  $(visibleSlider).css('left').replace(/px/,'');
											
						leftDist = (leftDist == "0") ? 0 : parseInt(leftDist);					
						var postomove = leftDist - $('li a', visibleSlider).width();
						postomove = postomove +'px';				
							
							//alert(leftpos);
							$('.phoneleftclick').addClass('addcursoronimg phoneleftclickenab')
						
						//alert("counterxH " + counterxH + "countofmobileapps" + countofmobileapps);
							$(visibleSlider).animate({'left':postomove},300) 
						}
							$('ul#htop1 li a').css({"margin-top":0});
				
					}
			 
				}
			)
			
			$('.phonedownclick').click(function(){
				 
					    
		       if($('ul#htop1 li ul#fc'+counterxV).is(":visible") ) {
				   
				
		           var visibleSlider = 'ul#htop1 li ul#fc'+counterxV+':visible';
				   
				   
				    if($(visibleSlider).is(':animated')) {
					    return false;
				    }
					
					//alert(countofvmobileapps);
				    var counterxxx;
				    counterxxx = vsliderCounter.val();	
					//alert("in down -  countofvmobileapps ="+countofvmobileapps);
					
					
					if(counterxxx == countofvmobileapps) {
							
							$('.phonedownclick').addClass('phonedownclickdis').removeClass('addcursoronimg phoneupclickenab');
						}
					
				if(counterxxx < countofvmobileapps) 
					{			
					    counterxxx = parseInt(counterxxx) + 1;				
					    vsliderCounter.val(counterxxx);
						
						//alert($(visibleSlider).css('top'));
						$('ul#fc'+counterxV+'li').css('float', 'none');
						$('ul#fc'+counterxV+'li a').css('float', 'none');
					    var topDist =  $(visibleSlider).css('top').replace(/px/,'');
						    topDist = (topDist == "0") ? 0 : parseInt(topDist);
									
					    var postomove = topDist - $('li a', visibleSlider).height();
						//alert("postomove - "+postomove);
					    postomove = postomove +'px';	
					    								
						    $(visibleSlider).animate({'top':postomove},300); 
							  $('.phoneupclick').removeClass("phoneupclickdis").addClass('addcursoronimg phoneupclickenab');		
				
				    }
				 } else {
						
						$('ul#htop1 li ul#fc' + counterxV).show();
						//$('ul#htop1 li ul#fc'+counterxV+'.left').css(leftpos);
						 $('.phoneupclick').removeClass("phoneupclickdis").addClass('addcursoronimg phoneupclickenab');		
				
						$('ul#htop1 li ul#fc'+counterxV + 'li').css('float', 'none');
						$('ul#htop1 li ul#fc'+counterxV+ 'li a').css('float', 'none');
				 						//	}	
						}
				})
			
			
			$('.phoneleftclick').click( function(){
												  
					vsliderCounter.val("1");
					var visibleSlider = 'ul#htop1:visible';
					if($(visibleSlider).is(":animated")) {
						return false;
					}
					//var counterxxx;
					//counterxxx = sliderCounter.val();
					
					if(counterxH > 1) {				
						counterxH = parseInt(counterxH) - 1;				
						sliderCounter.val(counterxH);
						counterxV = counterxH;
						countofvmobileapps = $('ul#htop1 li ul#fc'+counterxV+' li', sliderContext).length;
						if(countofvmobileapps == 0){					
							$('.phonedownclick').removeClass('addcursoronimg phonedownclickenab').addClass('phonedownclickdis');
							 	}
					else{					
							$('.phonedownclick').removeClass('phonedownclickdis').addClass('addcursoronimg phonedownclickenab');
									 	}
					if(counterxH == 1)
						{ 
							//alert("counterxH in Right="+counterxH);
							$('.phoneleftclick').addClass('phoneleftclickdis').removeClass('addcursoronimg phoneleftclickenab');
						}
						var postomove1 = parseInt($(visibleSlider).css('left').replace(/px/,'')) + 
						$('li a', visibleSlider).width();
						postomove1 = postomove1 +'px';
						
						$(visibleSlider).animate({'left':postomove1},300);
						
						
						$('.phonerightclick').removeClass("phonerightclickdis").addClass('addcursoronimg')
					}
				}
			)
	
			$('.phoneupclick').click( function(){
					
					  if($('ul#htop1 li ul#fc'+counterxV).is(":visible") ) {							 
					var visibleSlider = 'ul#htop1 li ul#fc'+counterxV+':visible';
					if($(visibleSlider).is(":animated")) {
						return false;
					}
					var counterxxx;
					counterxxx = vsliderCounter.val();
					//alert(counterxxx);
					if(counterxxx > 0) {				
						counterxxx = parseInt(counterxxx) - 1;				
						vsliderCounter.val(counterxxx);
						
					/*if(counterxxx > 1) {
							$('.phoneupclick').removeClass('phoneupclickdis').addClass('addcursoronimg phoneupclickenab');
						}	*/
						if(counterxxx == 0){
							
							 $('.phoneupclick').addClass("phoneupclickdis").removeClass('addcursoronimg phoneupclickenab');
							}
						 
						 
														
						var postomove1 = parseInt($(visibleSlider).css('top').replace(/px/,''));
						postomove1 = postomove1 + $('li a', visibleSlider).height();
						postomove1 = postomove1 + 'px';
						$(visibleSlider).animate({'top':postomove1},300);
						$('.phonedownclick').removeClass("phonedownclickdis").addClass('addcursoronimg');
					}
				}
				else{
				
						$('ul#fc'+ counterxV).show();
						$('ul#fc'+ counterxV).children('li').css('float', 'none');
						$('ul#fc'+ counterxV).children('li a').css('float', 'none');
				
				}
			}
			
			)
			
		}
		

		
							
	});
	