// JavaScript Document
$(document).ready(function(){
	
	if(PG_name == "PG_anddroid"){
		var boxheight = 340;
		var boxwidth = 215;
		
		$(".maskingbox").css("margin-top","2px");
		$(".maskingbox").css("margin-left","26px");
		
		$("#leftmove").css("top","235px");
		$("#leftmove").css("left","430px");
		
		$("#rightmove").css("top","235px");
		$("#rightmove").css("left","100px"); 
		
		$("#topmove").css("top","515px");
		$("#topmove").css("left","265px");
		
		$("#bottommove").css("top","-30px");
		$("#bottommove").css("left","265px");  
	}
	
	if(PG_name == "PG_iPhone"){
		var boxheight = 323;
		var boxwidth = 224;
		
		$(".maskingbox").css("margin-top","-1px");
		$(".maskingbox").css("margin-left","22px");
		
		$("#leftmove").css("top","235px");
		$("#leftmove").css("left","430px");
		
		$("#rightmove").css("top","235px");
		$("#rightmove").css("left","100px"); 
		
		$("#topmove").css("top","530px");
		$("#topmove").css("left","265px");
		
		$("#bottommove").css("top","-33px");
		$("#bottommove").css("left","265px");  
	}
	
	if(PG_name == "PG_iPad"){
		var boxheight = 410;
		var boxwidth = 308;
		
		$(".maskingbox").css("margin-top","-1px");
		$(".maskingbox").css("margin-left","46px");
				
		$("#leftmove").css("top","235px");
		$("#leftmove").css("left","495px");
		
		$("#rightmove").css("top","235px");
		$("#rightmove").css("left","35px"); 
		
		$("#topmove").css("top","515px");
		$("#topmove").css("left","265px");
		
		$("#bottommove").css("top","-30px");
		$("#bottommove").css("left","265px");  
	}
	
		
	$(".maskingbox").height(boxheight);
	$(".maskingbox").width(boxwidth);
	$(".maskingbox ul li").width(boxwidth);
	$(".maskingbox ul li img").height(boxheight);
	$(".maskingbox ul li img").width(boxwidth);
	
	$(".maskingbox ul").width($(".maskingbox ul li").length*boxwidth) // set UL in fix width to so that all li will come in one line
	var Totalcolum = $(".maskingbox ul li").length; // Total length of coloums
	var Hcount = 1; // To check left right moves
	var Vcount = 1; // To check top bottom moves
	var currentCol = 1; // To check top bottom moves

	
	/* define vcol ID*/
	$('.maskingbox').find("li").each(function(index){
		var theId = 'Vcol_' + (index+1);
		$(this).attr("id", theId);
		$(this).append();
	})
	
	var Vimgs = $("#Vcol_"+currentCol+" img").length; // Find how many images are in current col
	if(Vimgs==1){
		$("#topmove").removeClass("topmove_enable");
		$("#topmove").addClass("topmove_gray");
		}
 
	
	/* left moves */
	$("#leftmove").live("click",function(){
		$("#bottommove").addClass("bottommove_gray");
		$("#bottommove").removeClass("bottommove_enable");
		if(Hcount>=Totalcolum){
			return false;
		}else{
			$("#rightmove").addClass("rightmove_enable");
			$("#rightmove").removeClass("rightmove_gray");
			$(this).removeClass("leftmove_gray");
			$(this).addClass("leftmove_enable") 
			var nextLi = currentCol +1;
			$("#Vcol_"+nextLi).css("margin-top","0");
			
			$(".maskingbox ul").animate({"left": "-="+boxwidth+"px"}, "slow");
			
			var NextVimgs = $("#Vcol_"+nextLi+" img").length; // Find how many images are in current col
			if(NextVimgs==1){
				$("#topmove").addClass("topmove_gray");
				$("#topmove").removeClass("topmove_enable");
			}else{
				$("#topmove").removeClass("topmove_gray");
				$("#topmove").addClass("topmove_enable");
			}
			
			Vcount = 1;
			Hcount += 1;
			Vimgs = $("#Vcol_"+currentCol+" img").length; // Find how many images are in current col 
			
			if(Hcount>=Totalcolum){
				$(this).removeClass("leftmove_enable");
				$(this).addClass("leftmove_gray")
				}
			currentCol +=1;
			var Vimgs = $("#Vcol_"+currentCol+" img").length; // Find how many images are in current col 
		}
	})
	
	/* right moves */
	$("#rightmove").live("click",function(){ 
		$("#bottommove").addClass("bottommove_gray");
		$("#bottommove").removeClass("bottommove_enable");
		if(Hcount<=1){
			$(this).removeClass("rightmove_enable");
			$(this).addClass("rightmove_gray")
			return false;
		}else{ 
			$("#leftmove").addClass("leftmove_enable");
			$("#leftmove").removeClass("leftmove_gray");
			$(this).removeClass("rightmove_gray");
			$(this).addClass("rightmove_enable") 
			
			prevLi = currentCol -1;
			$("#Vcol_"+prevLi).css("margin-top","0");
			$(".maskingbox ul").animate({"left": "+="+boxwidth+"px"}, "slow");
			Vcount = 1;
			Hcount -=1;
			
			var PrevVimgs = $("#Vcol_"+prevLi+" img").length; // Find how many images are in current col
			if(PrevVimgs==1){
				$("#topmove").addClass("topmove_gray");
				$("#topmove").removeClass("topmove_enable");
			}else{
				$("#topmove").removeClass("topmove_gray");
				$("#topmove").addClass("topmove_enable");
			}
			 
			if(Hcount==1){
				$(this).addClass("rightmove_gray");
				$(this).removeClass("rightmove_enable");
			 }
			currentCol -=1;
			var Vimgs = $("#Vcol_"+currentCol+" img").length; // Find how many images are in current col 
		}
	}) 
	
	/* top moves */
	$("#topmove").live("click",function(){
		var Vimgs = $("#Vcol_"+currentCol+" img").length; // Find how many images are in current col
		if(Vimgs>Vcount){
			Vcount +=1;
			if(Vcount==Vimgs){
				$(this).removeClass("topmove_enable");
				$(this).addClass("topmove_gray");
				$("#bottommove").removeClass("bottommove_gray");
				$("#bottommove").addClass("bottommove_enable");
			}
			
			if ($.browser.msie && $.browser.version ) {
				boxheight = boxheight+1;
				$("#Vcol_"+currentCol).animate({"margin-top": "-="+boxheight+"px"}, "slow");
			}else{
				$("#Vcol_"+currentCol).animate({"margin-top": "-="+boxheight+"px"}, "slow");	
				}
			
				$("#bottommove").removeClass("bottommove_gray");
				$("#bottommove").addClass("bottommove_enable");
			}else{
				return false;
			}
	})
	
	/* bottom moves */
	$("#bottommove").live("click",function(){
		if(Vcount>1){
			Vcount -=1;
				if ($.browser.msie && $.browser.version ) {
				boxheight = boxheight-1;
					$("#Vcol_"+currentCol).animate({"margin-top": "+="+boxheight+"px"}, "slow");
				}else{
					$("#Vcol_"+currentCol).animate({"margin-top": "+="+boxheight+"px"}, "slow");
				}
				
				
				if(Vcount==1){
					$(this).removeClass("bottommove_enable");
					$(this).addClass("bottommove_gray");
					$("#topmove").addClass("topmove_enable");
					$("#topmove").removeClass("topmove_gray");
					}
					$("#topmove").addClass("topmove_enable");
					$("#topmove").removeClass("topmove_gray");
			}else{
				return false;
			} 
	})
})